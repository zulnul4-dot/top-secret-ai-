const OpenAI = require("openai");

const MAX_MESSAGES = 20;
const MAX_MESSAGE_CHARS = 4000;
const MAX_TOTAL_CHARS = 12000;

module.exports = async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed. Use POST." });
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return res.status(503).json({
      error: "AI is not configured yet. Add OPENAI_API_KEY in your Vercel project environment variables, then redeploy."
    });
  }

  let body = req.body;
  try {
    if (typeof body === "string") body = JSON.parse(body);
    if (!body && req.headers["content-type"]?.includes("application/json")) {
      body = await new Promise((resolve, reject) => {
        let raw = "";
        req.on("data", chunk => {
          raw += chunk;
          if (raw.length > 100_000) reject(new Error("Request too large"));
        });
        req.on("end", () => {
          try { resolve(JSON.parse(raw || "{}")); } catch (err) { reject(err); }
        });
        req.on("error", reject);
      });
    }
  } catch {
    return res.status(400).json({ error: "Invalid JSON request." });
  }

  if (!body || !Array.isArray(body.messages)) {
    return res.status(400).json({ error: "Send a messages array." });
  }

  const messages = body.messages;
  if (messages.length < 1 || messages.length > MAX_MESSAGES) {
    return res.status(400).json({ error: `Send between 1 and ${MAX_MESSAGES} messages.` });
  }

  let totalChars = 0;
  const safeMessages = [];
  for (const item of messages) {
    if (!item || !["user", "assistant"].includes(item.role) || typeof item.content !== "string") {
      return res.status(400).json({ error: "Each message needs a valid role and text content." });
    }
    const content = item.content.trim();
    if (!content || content.length > MAX_MESSAGE_CHARS) {
      return res.status(400).json({ error: `Each message must be 1–${MAX_MESSAGE_CHARS} characters.` });
    }
    totalChars += content.length;
    safeMessages.push({ role: item.role, content });
  }

  if (totalChars > MAX_TOTAL_CHARS) {
    return res.status(400).json({ error: "Conversation is too long. Clear the chat and try again." });
  }
  if (safeMessages[safeMessages.length - 1].role !== "user") {
    return res.status(400).json({ error: "The latest message must be from the user." });
  }

  try {
    const client = new OpenAI({ apiKey });
    const result = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.5",
      instructions:
        "You are System AI inside the TOP SECRET website. Be helpful, clear, and friendly. " +
        "Answer the user's actual question. You can help with general learning, HTML, CSS, JavaScript, and Roblox Studio scripting. " +
        "Do not claim to have deployed or changed files unless that actually happened. " +
        "If asked about this site, explain that the Scripting Editor exports code as text and does not execute or inject scripts. " +
        "Keep answers age-appropriate. Do not ask for passwords, API keys, or other secrets.",
      input: safeMessages,
      max_output_tokens: 900
    });

    const reply = (result.output_text || "").trim();
    if (!reply) {
      return res.status(502).json({ error: "The AI returned no text. Please try again." });
    }
    return res.status(200).json({ reply });
  } catch (error) {
    // Log only a short diagnostic; never return secret values to the browser.
    console.error("System AI request failed:", error?.status || error?.name || "Unknown error");
    const status = error?.status === 401 ? 502 : 502;
    return res.status(status).json({
      error: error?.status === 401
        ? "The server API key was rejected. Check OPENAI_API_KEY in Vercel."
        : "The AI service could not answer right now. Check API access, billing, and deployment logs."
    });
  }
};
