# TOP SECRET — OpenAI System AI (Vercel)

This package contains the website and a Vercel serverless endpoint. The browser calls `/api/chat`; the OpenAI API key is read only on the server from `process.env.OPENAI_API_KEY`.

## Files

- `index.html` — TOP SECRET site, including embedded MP3, four pages, social links, Learn guide, and live AI chat UI.
- `api/chat.js` — server-side OpenAI Responses API endpoint.
- `package.json` — OpenAI JavaScript SDK dependency.
- `.env.example` — variable names only; it does not contain a real key.

## Deploy using GitHub + Vercel

1. Extract this ZIP.
2. Put the files and `api` folder into one GitHub repository. Keep `index.html` in the project root.
3. In Vercel, choose **Add New → Project**, import that repository, and deploy it. No framework preset is needed for this plain HTML + Vercel Functions project.
4. In the Vercel project, open **Settings → Environment Variables**.
5. Add `OPENAI_API_KEY` with your own secret API key. Add it to the Production environment (and Preview too if you want to test previews).
6. Optionally add `OPENAI_MODEL` with a model available to your API project. The default in this package is `gpt-5.5`; change it if your account does not have access to that model.
7. Save the variables, then open **Deployments** and redeploy the latest deployment so the function receives them.
8. Open the deployed `https://your-project.vercel.app` site, go to **04 / System AI**, and send a test message.

Official docs:
- OpenAI API quickstart: https://developers.openai.com/api/docs/quickstart
- OpenAI API key safety: https://developers.openai.com/api/reference/overview
- Vercel Node.js Functions: https://vercel.com/docs/functions/runtimes/node-js
- Vercel environment variables: https://vercel.com/docs/environment-variables

## Important security notes

- **Never** paste your API key into `index.html`, frontend JavaScript, GitHub, or a public chat.
- Store the key only as the `OPENAI_API_KEY` environment variable in Vercel. If you accidentally publish it, revoke it and create a replacement.
- API usage may incur charges; set usage limits/alerts in your OpenAI platform account.
- This starter validates request shape and limits message count/length, but it does not include production-grade per-user rate limiting or sign-in. Before sharing publicly, add rate limiting/abuse protection and any required access control.
- The current Sign In/Guest UI is a local visual profile only; it is not authentication.
- The AI needs internet access and a valid OpenAI API account/key. Downloading/opening the HTML file locally will not make `/api/chat` work; deploy the full project to Vercel.
